check(window);
check(this);
check(globalThis);
check(location);
check(globalThis["win" + "dow"])
