declare const scramjetPath: string;

export { scramjetPath };
