// see types.d.ts for what these mean
export const SCRAMJETCLIENTNAME = "scramjet client global";
export const SCRAMJETCLIENT = Symbol.for(SCRAMJETCLIENTNAME);
export const SCRAMJETFRAME = Symbol.for("scramjet frame handle");
