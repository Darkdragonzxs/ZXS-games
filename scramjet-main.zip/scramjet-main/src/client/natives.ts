export const nativeFunction = self.Function;
export const nativeGetOwnPropertyDescriptor =
	self.Object.getOwnPropertyDescriptor;
