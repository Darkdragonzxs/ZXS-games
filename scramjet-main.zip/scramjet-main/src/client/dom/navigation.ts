export default function (client, self: Self) {
	// @ts-ignore
	delete self.navigation;
}
